/* pipwrite.c -pipwrite */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  pipwrite
 *------------------------------------------------------------------------
 */
int32	pipwrite(pipid32 pipid, char *buf, uint32 len)
{
	intmask	mask;			/* saved interrupt mask		*/
	int32 counter = 0;
	// int32 temp;
	struct pipentry *piptr;

	if (isbadpip(pipid)
		|| len < 0){
		restore(mask);
		return SYSERR;
	}
	
	piptr = &piptab[pipid];

	// if (piptr->pwriter != currpid
	// 	|| piptr->pstate != PIPE_CONNECTED){
	// 	restore(mask);
	// 	return SYSERR;
	// }

	while (counter < len){
		if (piptr->pipbuffer.count > PIPE_SIZE){
			wait(piptr->sem_full);
		}
		piptr->pipbuffer.elems[counter] = writebuff(buf);
	}

	signal(piptr->sem_empty);

	restore(mask);
	return counter;
}
