/* pipread.c -pipread */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  pipread
 *------------------------------------------------------------------------
 */
int32	pipread(pipid32 pipid, char *buf, uint32 len)
{
	intmask	mask;			/* saved interrupt mask		*/
	struct pipentry *piptr;

	if (isbadpip(pipid)
		|| len < 0){
		restore(mask);
		return SYSERR;
	}
	
	piptr = &piptab[pipid];

	// check if the process is the reader
	// if (piptr->preader != currpid
	// 	|| piptr->pstate != PIPE_CONNECTED){
	// 	restore(mask);
	// 	return SYSERR;
	// }

	int counter = 0;

	if(piptr->prbuffer.count < 0){
		wait(piptr->sem_empty);
	}
	
	while (counter < len){
		buf[counter] = readbuff(piptr->pipbuffer.elems);
	}

	signal(piptr->sem_full);

	// buf[count] = '\0';
	restore(mask);
	return counter;
}

